from selenium import webdriver
import pandas as pd
import matplotlib.pyplot as plt
browser = webdriver.Chrome('/Users/cristiansoria/Downloads/chromedriver')

browser.get('https://robinhood.com/collections/100-most-popular')
header = browser.find_elements_by_class_name("kg7H31Ap4MW-dg1bFNOGP")
name = browser.find_elements_by_class_name("_6M0lojguuu-oGcosChSe6")
table = browser.find_elements_by_class_name("_2fax8HRY62uCbHnshxhsBl")
name = [header[0].text]
symbol = [header[1].text]
price = [header[2].text]
today_per = [header[3].text]
market_cap = [header[4].text]
popularity = [header[5].text]
rating = [header[6].text]

counter = 0
for line in range(0,len(table),7):
    name.append(table[counter].text)
    counter+=1
    symbol.append(table[counter].text)
    counter+=1
    price.append(table[counter].text)
    counter+=1
    today_per.append(table[counter].text)
    counter+=1
    market_cap.append(table[counter].text)
    counter+=1
    popularity.append(table[counter].text)
    counter+=1
    rating.append(table[counter].text)
    counter+=1

d = [name, symbol, price, today_per, market_cap, popularity, rating]
df = pd.DataFrame(data=d)
export_csv = df.to_csv('file1.csv')
print(df)
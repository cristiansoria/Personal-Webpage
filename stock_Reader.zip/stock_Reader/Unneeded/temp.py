def write():
    FILE = open("NYSE_20191104.txt", "r")
    global counter
    f = open("stocks.txt", "w")
    for line in FILE:
        values = line.split(",")
        if(check(values[0])): 
            f.write(values[0] + ", \n")
    FILE.close()

def check(tik):
    for element in range(0, len(tik)): 
        if(tik[element] == "." or tik[element] == "-"):
            return False
        else:
            answer = True
    return answer

write()
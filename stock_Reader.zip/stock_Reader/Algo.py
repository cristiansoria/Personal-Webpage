
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
from alpha_vantage.sectorperformance import SectorPerformances
from alpha_vantage.cryptocurrencies import CryptoCurrencies
from pprint import pprint
import time
import alpacaClient
import json
import pandas as pd
# import matplotlib.pyplot as plt
# from selenium import webdriver


class Algo:
    global stocks, overSoldStock, counter, idk, keys
    stocks = ["SNAP", "UGAZ"]
    # stocks = {}
    overSoldStock = {}
    # df = pd.read_csv("top100.csv")
    # stocks = list(set(df["Symbol"].values.tolist()))
    stocksBought = []
    counter = 0
    num = 0
    idk = 0
    # def printRSI():
    #     global keys, idk, oversoldStock
    #     idk = 4
    #     place = 0
    #     num = 0
    #     for i in range(counter):
    #         if(i%5 == 0):
    #             time.sleep(60)
    #         if(idk == 4):
    #             idk = 0
    #             num += 1
    #             key = keys[num]
    #             if(num == 24):
    #                 num = 0
    #         ticker = str(stocks[place])
    #         print(ticker)
    #         try:
    #             ti = TechIndicators(key=key, output_format ='pandas')
    #             data, meta_data = ti.get_rsi(symbol=ticker, interval='daily', time_period=14, series_type='close')
    #             print(data.tail(1))
    #             string = str(data.tail(1))
    #             for number in string.split():
    #                 rsi = number
    #             try:    
    #                 if(float(rsi) < float(30)):
    #                     overSoldStock[ticker] = rsi
    #                     with open("RSIWatch.txt" , "a") as FILE:
    #                         FILE.write(str(ticker) + ",\n")
    #             except:
    #                 print("unable")
            
    #         except:
    #              print("No Value")
    #         place += 1
    #         idk += 1
    #     FILE.close()

    def getStocks():
        f = open("stocks.txt", "r")
        global stocks, counter
        for line in f:
            value = line.split(",")
            stocks[counter] = value[0]
            counter += 1



    def marketHours():
        global overSoldStock, idk, stocksBought
        
        def marketOpen():
            bol = False
            h = time.localtime(time.time()).tm_hour,time.localtime(time.time()).tm_min
            if((6,30) < (h) and (15,30) > (h)):
                bol = True
            return bol
        def checkRSI(ticker, key):
            try:
                ti = TechIndicators(key=key, output_format ='pandas')
                data, meta_data = ti.get_rsi(symbol=ticker, interval='30min', time_period=14, series_type='close')
                print(data.tail(2))
                string = str(data.tail(1))
                for number in string.split():
                    rsi = number
                bol = False
                if (float(rsi) > float(33)) and (float(rsi) < float(71)):
                    bol = True
            except:
                bol = False
            return bol

        def checkMACD(ticker, key):
            try:
                ti = TechIndicators(key=key, output_format='pandas',fastperiod='12', slowperiod='26', signalperiod='9')
                data, meta_data = ti.get_macd(symbol=str(ticker), interval='30min', series_type='close')
                df = data["MACD_Hist"].head(2)
                print(df)
                macd = float(df.iloc[-1])
            except:
                macd = 0.0
            return macd
        
        def get_soch(ticker, key):
            try:
                ti = TechIndicators(key=key, output_format ='pandas')
                data, meta_data = ti.get_stoch(symbol = ticker, interval='30min')
                print(data.head(2))
                parsed_json = data.head(1)
                SlowD = parsed_json['SlowD']
                SlowK = parsed_json['SlowK']
                d = float(SlowD.iloc[-1])
                k = float(SlowK.iloc[-1])
                bol = False
                if k<40:
                    return(d<k)    
                else:
                    return False     
            except:
                return False   
        
        def get_ema(ticker, key):
            ti = TechIndicators(key=key, output_format ='pandas')
            data, meta_data = ti.get_ema(ticker, interval='30min', time_period=9, series_type='close')
            parsed_json = data.head(2)
            ema = parsed_json["EMA"]
            e = float(ema.iloc[-1])
            print("e = ", e)
            return e
        
        def get_price(ticker, key):
            ts = TimeSeries(key=key, output_format='pandas')
            data, meta_data = ts.get_intraday(ticker, interval='30min', outputsize='compact')
            parsed_json = data.tail(1)
            print(data.tail())
            low = parsed_json["3. low"]
            l = float(low.iloc[-1])
            print("low = ", l)
            return l
            


        while(marketOpen()):
            iter = 0
            num = 0
            global stocks
            stocksBought = []
            key = "BMU49E2VTL4596KE"

            while(iter < len(stocks)-1):
                num+=1
                iter+=1
                ticker = stocks[iter]
                if(num == 24):
                    time.sleep(40)
                    num = 0
                print(ticker)
                rsi = checkRSI(ticker,key)
                macd = float(checkMACD(ticker, key)) > float(0.1)
                soch = get_soch(ticker, key)
                # print(rsi)
                e = get_ema(ticker, key)
                low = get_price(ticker, key)
                print("macd = ", macd)
                print("ema = ",e>low)
                print("soch = ", soch)
                print("rsi = ", rsi)
                if(macd and (e>low) and soch and rsi and (low<float(100))):
                    alpacaClient.create_order(ticker, 200, "buy", "market", "day")
                    stocksBought.append(ticker)
                    print("Bought")
                elif(str(ticker) in stocksBought):
                    if(macd == False):
                        print("sell" + ticker + time.localtime(time.time()).tm_hour,time.localtime(time.time()).tm_min)
                        alpacaClient.create_order(ticker, 200, "sell", "market", "day")
                
            
    # def get_top100():
    #     browser = webdriver.Chrome('/Users/cristiansoria/Downloads/chromedriver')
    #     # browser.get('https://robinhood.com/collections/100-most-popular')
    #     browser.get('https://robinhood.com/collections/upcoming-earnings')
    #     header = browser.find_elements_by_class_name("kg7H31Ap4MW-dg1bFNOGP")
    #     table = browser.find_elements_by_class_name("_2fax8HRY62uCbHnshxhsBl")
    #     name = [header[0].text]
    #     symbol = [header[1].text]
    #     price = [header[2].text]
    #     today_per = [header[3].text]
    #     market_cap = [header[4].text]
    #     popularity = [header[5].text]
    #     rating = [header[6].text]
    #     counter = 0
    #     for line in range(0,len(table),7):
    #         name.append(table[counter].text)
    #         counter+=1
    #         symbol.append(table[counter].text)
    #         counter+=1
    #         price.append(table[counter].text)
    #         counter+=1
    #         today_per.append(table[counter].text)
    #         counter+=1
    #         market_cap.append(table[counter].text)
    #         counter+=1
    #         popularity.append(table[counter].text)
    #         counter+=1
    #         rating.append(table[counter].text)
    #         counter+=1
    #     d = [name, symbol, price, today_per, market_cap, popularity, rating]
    #     df = pd.DataFrame(data=d)
    #     export_csv = df.to_csv('file1.csv')
    #     return df
                    
    # getStocks() 
    # printRSI()
    
    # # df_copy = get_top100()
    # print(df_copy)
    marketHours()


from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
import time
import alpacaClient
import json
import pandas as pd 

# df_NYSE = pd.read_csv("Allstocks.csv")
# stocks = list(set(df_NYSE["Symbol"].values.tolist()))
# stocks.sort()
global stocks
stocks = {}

def get_indicators(ticker):
    key = 'BMU49E2VTL4596KE'
    ti = TechIndicators(key = key, output_format='pandas')
    ts = TimeSeries(key = key, output_format='pandas')
    # RSI
    # data_rsi, meta_data_rsi = ti.get_rsi(symbol = ticker, interval='30min', time_period='14', series_type='close')
    # rsi = float(data_rsi.tail(1)["RSI"].iloc[-1])
    try:
        data_rsi, meta_data_rsi = ti.get_rsi(symbol = ticker, interval='60min', time_period='14', series_type='close')
        rsi = float(data_rsi.tail(1)["RSI"].iloc[-1])
        # data_intra, meta_data_intra = ts.get_intraday(ticker, interval='30min', outputsize='compact')
        # low = data_intra.head(1)['4. close'].iloc[-1]
        if rsi < float(25):
            # with open("stocksUnder50.txt", "a") as FILE:
            #     FILE.write(ticker + ",\n")
            print(ticker, "  ", rsi)
    except:
        print("Can't get ", ticker)

def getStocks():
    f = open("stocksUnder50.txt", "r")
    # f = open("list.txt")
    global stocks
    counter = 0
    for line in f:
        value = line.split(",")
        stocks[counter] = value[0]
        counter += 1    

getStocks()

for i in range(len(stocks)):
    get_indicators(stocks[i])
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
import time
import alpacaClient
import json
import pandas as pd 

global stocks, stocksBought, price
stocksBought = []
stocks = {}
price = 0
# df = pd.read_csv("S&P500.csv")
# stocks = list(set(df["Tickers"].values.tolist()))
# stocks.sort()

def marketHours():
    h = time.localtime(time.time()).tm_hour,time.localtime(time.time()).tm_min
    return ((6,30) < h and h < (15,30))

def get_indicators(ticker):
    key = 'BMU49E2VTL4596KE'
    ti = TechIndicators(key = key, output_format='pandas')
    ts = TimeSeries(key = key, output_format='pandas')
    # EMA
    data_ema, meta_data_ema = ti.get_ema(ticker, interval='30min', time_period=9, series_type='close')
    data_intra, meta_data_intra = ts.get_intraday(ticker, interval='30min', outputsize='compact')

    for i in range(7):
        ema = data_ema["EMA"].tail(i+1).iloc[-1]
        close = data_intra.head(i+1)['4. close'].iloc[-1]
        if(ema<close):
            idk = True
        else:
            idk = False
            break

    return (idk and ema[1] < float(50))

def getStocks():
    # f = open("stocksUnder50.txt", "r")
    f = open("s&p500.txt")
    global stocks
    counter = 0
    for line in f:
        value = line.split(",")
        stocks[counter] = value[0]
        counter += 1
        
# If oversold and it is testing a support level and prev close < close buy? MACD
getStocks()
iter = 0
while(True):
    ticker = stocks[iter]
    # print(ticker)
    iter+=1
    if(iter>len(stocks)-1):
        iter = 0

    try:
        ans = get_indicators(ticker)
    except:
        ans = False
        print("Error")

    if(ans):
        alpacaClient.create_order(ticker, 1, "buy", "market", "day")
        print("Bought " , ticker, " at ", price)
        stocksBought.append(ticker)
    elif ticker in stocksBought:
            # alpacaClient.create_order(ticker, 1, "sell", "market", "day")
            # stocksBought.remove(ticker)
            print("Sold ", ticker)
    # except:    
    #     print("Error getting ", ticker)
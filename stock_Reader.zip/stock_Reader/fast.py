from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
import time
import alpacaClient
import json
import pandas as pd 

counter = 0
df = pd.read_csv("S&P500.csv")
stocks = list(set(df["Symbol"].values.tolist()))
stocks.sort()
f = open("list.txt", "a")
# key = 'BMU49E2VTL4596KE'
# ts = TimeSeries(key = key, output_format='pandas')

while(counter != len(stocks)):
    ticker = stocks[counter]
    counter +=1
    f.write(str(ticker) + ",\n")
f.close()
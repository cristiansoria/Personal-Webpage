from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators
import time
import alpacaClient
import json
import pandas as pd 

global stocks, stocksBought, price
stocksBought = []
stocks = {}
price = 0
# df = pd.read_csv("S&P500.csv")
# stocks = list(set(df["Tickers"].values.tolist()))
# stocks.sort()

def marketHours():
    h = time.localtime(time.time()).tm_hour,time.localtime(time.time()).tm_min
    return ((6,30) < h and h < (15,30))

def get_indicators(ticker):
    key = 'BMU49E2VTL4596KE'
    ti = TechIndicators(key = key, output_format='pandas')
    ts = TimeSeries(key = key, output_format='pandas')
    # RSI
    # data_rsi, meta_data_rsi = ti.get_rsi(symbol = ticker, interval='30min', time_period='14', series_type='close')
    # rsi = float(data_rsi.tail(1)["RSI"].iloc[-1])
    # print(data_rsi.tail(1))
    # MACD
    data_macd, meta_data_macd = ti.get_macd(symbol=str(ticker), interval='60min', series_type='close',fastperiod='12', slowperiod='26', signalperiod='9')
    # print(data_macd.head(1))
    macdHist = float(data_macd["MACD_Hist"].head(1).iloc[-1])
    macd = float(data_macd["MACD"].head(1).iloc[-1])
    prevMacd = float(data_macd["MACD"].head(2).iloc[-1])
    # print(data_macd)
    # EMA
    data_ema, meta_data_ema = ti.get_ema(ticker, interval='60min', time_period=9, series_type='close')
    ema = data_ema["EMA"].tail(1).iloc[-1]
    # print(data_ema.tail(1))
    # Stoch
    # data_stoch, meta_data_stoch = ti.get_stoch(symbol = ticker, interval='30min')
    # # print(data_stoch.head(1))
    # slowD = data_stoch.head(1)['SlowD'].iloc[-1]
    # slowK = data_stoch.head(1)['SlowK'].iloc[-1]
    # Intraday
    data_intra, meta_data_intra = ts.get_intraday(ticker, interval='60min', outputsize='compact')
    # print(data_intra.head(1))
    close = data_intra.head(1)['4. close'].iloc[-1]
    preClose = data_intra.head(2)['4. close'].iloc[-1]
    lastClose = data_intra.head(3)['4. close'].iloc[-1]
    # # print(data_intra.head(3))
    # lastLow = data_intra.head(3)['4. close'].iloc[-1]
    # volume = data_intra.head(1)['5. volume'].iloc[-1]
    # prevVol = data_intra.head(2)['5. volume'].iloc[-1]
    data_vwap, meta_data_vwap = ti.get_vwap(ticker, interval = '60min')
    vwap = data_vwap.tail(1)['VWAP'].iloc[-1]
    # print(vwap)
    a = macd-prevMacd
    price = preClose + (close-preClose)/2

    return (macdHist > 0.0 and a > 0.0 and preClose < vwap and close > vwap and ema < close and close < float(50))

def getStocks():
    # f = open("stocksUnder50.txt", "r")
    f = open("s&p500.txt")
    global stocks
    counter = 0
    for line in f:
        value = line.split(",")
        stocks[counter] = value[0]
        counter += 1

# If oversold and it is testing a support level and prev close < close buy? MACD
getStocks()
iter = 0
while(True):
    ticker = stocks[iter]
    # print(ticker)
    iter+=1
    if(iter>len(stocks)-1):
        iter = 0

    # try:
    try:
        ans = get_indicators(ticker)
    except:
        ans = False
        print("Error")
    # print(ans)
    if(ans):
        alpacaClient.create_order(ticker, 1, "buy", "market", "day")
        print("Bought " , ticker, " at ", price)
        stocksBought.append(ticker)
    elif ticker in stocksBought:
            # alpacaClient.create_order(ticker, 20, "sell", "market", "day")
            # stocksBought.remove(ticker)
            print("Sold ", ticker)
    # except:    
    #     print("Error getting ", ticker)